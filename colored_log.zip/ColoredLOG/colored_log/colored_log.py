from termcolor import *
import colorama
import datetime
colorama.init()

class LOG:
    def __init__(self, text, color):
        print(colored(f"[{datetime.datetime.now()}] {text}", color))
