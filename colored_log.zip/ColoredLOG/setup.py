from setuptools import *

setup(
    name="colored_log",
    version="0.0.1",
    description="Simple and Clean to use Logging.",
    packages=["colored_log"],
    zip_safe=False)