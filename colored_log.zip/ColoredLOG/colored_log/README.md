
# Colored Log

Simple and clean python LOG function can be used in many ways and provides a simple to read print.


### Installation

```
pip install -U colored_log
```

### Basic Usage
```
from colored_log.colored_log import LOG

LOG("Hi!", "red)
```


### LOG in Different Colors 
Red:
```LOG("Hi!", "red")```

Green:
```LOG("Hi!", "green")```

Blue: ```LOG("Hi!", "blue)```

### Available Colors

black, 
red, green, yellow, blue, magenta, cyan, white.


